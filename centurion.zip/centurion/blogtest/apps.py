from django.apps import AppConfig


class BlogtestConfig(AppConfig):
    name = 'blogtest'
